# GL SERVAS NR I — Compilação automática do APK

Este projeto está preparado para gerar um APK usando GitHub Actions, sem precisar instalar Android Studio no celular.

## Pelo celular

1. Crie um repositório no GitHub, de preferência privado, chamado `GL-Servas-NR-I`.
2. Extraia o ZIP e envie **o conteúdo da pasta `GL_Servas_NR_I_Android`** para a raiz do repositório. A pasta `.github/workflows/build-apk.yml` precisa ficar exatamente nesse caminho.
3. No GitHub, abra a aba **Actions**.
4. Selecione **Build GL Servas NR I APK**.
5. Toque em **Run workflow**.
6. Aguarde a execução terminar com sucesso.
7. Abra a execução concluída e procure **Artifacts**.
8. Baixe `GL-SERVAS-NR-I-v1.0-APK`.
9. Extraia o ZIP do artifact e instale o arquivo `.apk` no Android.

O workflow usa Java 17, Android SDK 35 e Gradle 8.10.2 e executa `:app:assembleDebug`.

## Observação

O APK é uma versão **debug**, adequada para instalação e testes. Para publicação na Google Play Store, posteriormente será necessário configurar assinatura de release (keystore) e gerar um AAB/APK de release.

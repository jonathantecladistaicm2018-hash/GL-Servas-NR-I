package br.com.glservas.nri;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        int[] ids = {R.id.btnAudios,R.id.btnCifrados,R.id.btnSemCifras,R.id.btnExperiencias,R.id.btnEnsaios,R.id.btnAvisos,R.id.btnPesquisa,R.id.btnFavoritos,R.id.btnAdmin};
        String[] names = {"Áudios","Hinos Cifrados","Hinos sem Cifras","Experiências","Ensaios","Avisos","Pesquisa","Favoritos","Administração"};
        for (int i=0;i<ids.length;i++) {
            final String name=names[i];
            Button b=findViewById(ids[i]);
            b.setOnClickListener(v -> Toast.makeText(this, name + " — módulo da versão 1.0", Toast.LENGTH_SHORT).show());
        }
    }
}
